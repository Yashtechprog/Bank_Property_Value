# Housing Valuation & Underwriting Streamlit App

Academic project: property price prediction for bank-style underwriting estimation.

## Repository contents

- `app.py` — Streamlit application
- `linear_regression_model.sav` — final linear regression valuation pipeline
- `logistic_regression_model.sav` — final logistic regression classification pipeline
- `model_metadata.sav` — optional separate copy of feature ranges, categories, metrics and model metadata. The app can also read this information from the trained model files if this file is absent.
- `requirements.txt` — Streamlit deployment dependencies

## Models

### Linear regression
Predicts `Price_INR_Lakhs` from the supplied property characteristics.

The final model is a linear regression fitted to `log1p(Price_INR_Lakhs)` and transformed back to rupee-lakh units for prediction. This remains a linear regression model while reducing the effect of extreme property values.

Validation metrics (20% holdout, random_state=42):
- MAE: 34.82 lakh
- RMSE: 74.63 lakh
- R²: 0.748

### Logistic regression
Predicts the probability that estimated/actual property value belongs to the high-value class:
`Price_INR_Lakhs >= 100` (₹1 crore).

Validation metrics (stratified 20% holdout, random_state=42):
- Accuracy: 0.888
- ROC-AUC: 0.963

The supplied data has no borrower income, loan amount, default, or sanction outcome. Therefore, the logistic model does **not** pretend to predict loan approval/default. The Streamlit app separately calculates LTV and FOIR from user-entered lending information.

## Streamlit Cloud deployment

1. Create a new GitHub repository.
2. Upload all files in this folder to the repository root.
3. Open Streamlit Community Cloud and select the repository.
4. Set the main file to `app.py`.
5. Deploy.

No CSV upload is required by the deployed app because the trained models are already serialized in the `.sav` files. The metadata is embedded in both trained model files, so `model_metadata.sav` is optional with the current `app.py`.

## Expected workflow

Property features → predicted property value → proposed loan amount → LTV.

Borrower income + existing obligations + proposed EMI → FOIR.

These outputs are for academic demonstration and should not be treated as an actual lending decision.
